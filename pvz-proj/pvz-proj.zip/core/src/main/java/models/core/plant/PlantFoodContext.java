package models.core.plant;

import models.core.projectile.Damage;
import models.core.zombie.Zombie;
import models.engine.board.Board;
import models.engine.board.Lane;
import models.engine.board.Position;
import models.engine.board.Tile;
import models.engine.combat.BoardTickResult;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.function.Consumer;
import java.util.function.BiConsumer;
import java.util.function.IntConsumer;

public class PlantFoodContext {
    private final Board board;
    private final PlantFactory plantFactory;
    private final Random random;
    private final IntConsumer sunAdder;
    private final BiConsumer<Plant, Integer> sunBurstSpawner;
    private final BiConsumer<Integer, Runnable> delayedActionScheduler;
    private final Consumer<BoardTickResult> resultRecorder;
    private final Consumer<Plant> plantPlacedHandler;
    private final Consumer<Plant> plantAgeResetHandler;

    public PlantFoodContext(
            Board board,
            PlantFactory plantFactory,
            Random random,
            IntConsumer sunAdder,
            Consumer<BoardTickResult> resultRecorder,
            Consumer<Plant> plantPlacedHandler,
            Consumer<Plant> plantAgeResetHandler
    ) {
        this(
                board,
                plantFactory,
                random,
                sunAdder,
                null,
                null,
                resultRecorder,
                plantPlacedHandler,
                plantAgeResetHandler
        );
    }

    public PlantFoodContext(
            Board board,
            PlantFactory plantFactory,
            Random random,
            IntConsumer sunAdder,
            BiConsumer<Plant, Integer> sunBurstSpawner,
            Consumer<BoardTickResult> resultRecorder,
            Consumer<Plant> plantPlacedHandler,
            Consumer<Plant> plantAgeResetHandler
    ) {
        this(
                board,
                plantFactory,
                random,
                sunAdder,
                sunBurstSpawner,
                null,
                resultRecorder,
                plantPlacedHandler,
                plantAgeResetHandler
        );
    }

    public PlantFoodContext(
            Board board,
            PlantFactory plantFactory,
            Random random,
            IntConsumer sunAdder,
            BiConsumer<Plant, Integer> sunBurstSpawner,
            BiConsumer<Integer, Runnable> delayedActionScheduler,
            Consumer<BoardTickResult> resultRecorder,
            Consumer<Plant> plantPlacedHandler,
            Consumer<Plant> plantAgeResetHandler
    ) {
        this.board = board;
        this.plantFactory = plantFactory;
        this.random = random == null ? new Random() : random;
        this.sunAdder = sunAdder;
        this.sunBurstSpawner = sunBurstSpawner;
        this.delayedActionScheduler = delayedActionScheduler;
        this.resultRecorder = resultRecorder;
        this.plantPlacedHandler = plantPlacedHandler;
        this.plantAgeResetHandler = plantAgeResetHandler;
    }

    public Board getBoard() {
        return board;
    }

    public void addSun(int amount) {
        if (amount > 0 && sunAdder != null) {
            sunAdder.accept(amount);
        }
    }

    public void spawnSunBurst(Plant source, int amount) {
        if (source == null || amount <= 0) {
            return;
        }
        if (sunBurstSpawner != null) {
            sunBurstSpawner.accept(source, amount);
            return;
        }
        addSun(amount);
    }

    public void damageLane(Plant source, int damage, String damageType) {
        if (board == null || source == null || damage <= 0) {
            return;
        }
        record(board.damageZombiesInLane(
                laneOf(source),
                damage,
                damageType,
                source.getName(),
                source.getType() == null ? "" : source.getType().getCategory()
        ));
    }

    public void damageArea(Plant source, int xRadius, int yRadius, int damage, String damageType) {
        if (board == null || source == null || damage <= 0) {
            return;
        }
        record(board.damageZombiesInArea(
                positionOf(source),
                Math.max(0, xRadius),
                Math.max(0, yRadius),
                damage,
                damageType,
                source.getName(),
                source.getType() == null ? "" : source.getType().getCategory()
        ));
    }

    public void damageAreaDelayed(
            Plant source,
            int xRadius,
            int yRadius,
            int damage,
            String damageType,
            int delayTicks
    ) {
        if (source == null || damage <= 0) {
            return;
        }
        runDelayed(delayTicks, () -> {
            if (source.isAlive()) {
                damageArea(source, xRadius, yRadius, damage, damageType);
            }
        });
    }

    public void runDelayed(int delayTicks, Runnable action) {
        if (action == null) {
            return;
        }
        if (delayTicks <= 0 || delayedActionScheduler == null) {
            action.run();
            return;
        }
        delayedActionScheduler.accept(delayTicks, action);
    }

    public void damageNearestInLane(Plant source, int damage, String damageType) {
        if (board == null || source == null || damage <= 0) {
            return;
        }
        Lane lane = board.getLaneAt(laneOf(source));
        if (lane == null) {
            return;
        }
        Zombie nearest = null;
        double best = Double.MAX_VALUE;
        for (Zombie zombie : lane.getAllZombies()) {
            if (zombie == null || !zombie.isAlive() || !board.isZombieOnLawn(zombie)
                    || board.isHypnotized(zombie) || zombie.getX() < source.getX()) {
                continue;
            }
            double distance = zombie.getX() - source.getX();
            if (distance < best) {
                best = distance;
                nearest = zombie;
            }
        }
        if (nearest != null) {
            nearest.recordDamageSource(source.getName(),
                    source.getType() == null ? "" : source.getType().getCategory(), damageType);
            nearest.takeDamage(new Damage(damage, damageType));
            if (!nearest.isAlive()) {
                record(board.removeDeadEntities());
            }
        }
    }

    public void damageRandomWithSplash(
            Plant source, int count, int directDamage, int splashDamage, String damageType
    ) {
        if (board == null || source == null || count <= 0 || directDamage <= 0) {
            return;
        }
        List<Zombie> targets = livingEnemies();
        Collections.shuffle(targets, random);
        int limit = Math.min(count, targets.size());
        for (int index = 0; index < limit; index++) {
            Zombie target = targets.get(index);
            Position center = new Position(
                    Math.max(1, Math.min(board.getWidth(), (int) Math.ceil(target.getX()))),
                    Math.max(1, Math.min(board.getHeight(), (int) Math.round(target.getY())))
            );
            target.recordDamageSource(source.getName(),
                    source.getType() == null ? "" : source.getType().getCategory(), damageType);
            target.takeDamage(new Damage(directDamage, damageType));
            if (splashDamage > 0) {
                record(board.damageZombiesInArea(center, 1, 1, splashDamage, damageType + " splash",
                        source.getName(), source.getType() == null ? "" : source.getType().getCategory()));
            }
        }
        record(board.removeDeadEntities());
    }

    public void damageRandom(Plant source, int count, int damage, String damageType) {
        if (board == null || source == null || count <= 0 || damage <= 0) {
            return;
        }
        record(board.damageRandomZombies(
                count,
                damage,
                damageType,
                random,
                source.getName(),
                source.getType() == null ? "" : source.getType().getCategory()
        ));
    }

    public void killRandom(Plant source, int count, String damageType) {
        if (board == null || source == null || count <= 0) {
            return;
        }
        List<Zombie> zombies = livingEnemies();
        Collections.shuffle(zombies, random);
        int limit = Math.min(count, zombies.size());
        for (int index = 0; index < limit; index++) {
            Zombie zombie = zombies.get(index);
            zombie.recordDamageSource(
                    source.getName(),
                    source.getType() == null ? "" : source.getType().getCategory(),
                    damageType
            );
            zombie.kill();
        }
        record(board.removeDeadEntities());
    }

    public void hypnotizeRandom(int count) {
        if (board == null || count <= 0) {
            return;
        }
        List<Zombie> zombies = livingEnemies();
        Collections.shuffle(zombies, random);
        for (int index = 0; index < Math.min(count, zombies.size()); index++) {
            board.hypnotizeZombie(zombies.get(index));
        }
    }

    public void freezeLane(Plant source, int ticks) {
        if (board == null || source == null || ticks <= 0) {
            return;
        }
        Lane lane = board.getLaneAt(laneOf(source));
        if (lane == null) {
            return;
        }
        for (Zombie zombie : lane.getAllZombies()) {
            board.applyFreeze(zombie, ticks);
        }
    }

    public void freezeAll(int ticks) {
        if (board != null && ticks > 0) {
            board.freezeAllZombies(ticks);
        }
    }

    public void butterAll(int ticks) {
        if (board == null || ticks <= 0) {
            return;
        }
        for (Zombie zombie : board.getAllZombies()) {
            board.applyButter(zombie, ticks);
        }
    }

    public void poisonLane(Plant source, int damagePerTick, int ticks) {
        if (board == null || source == null || damagePerTick <= 0 || ticks <= 0) {
            return;
        }
        Lane lane = board.getLaneAt(laneOf(source));
        if (lane == null) {
            return;
        }
        for (Zombie zombie : lane.getAllZombies()) {
            board.applyPoison(zombie, damagePerTick, ticks);
        }
    }

    public void pushLane(Plant source, double distance) {
        if (board == null || source == null || distance <= 0) {
            return;
        }
        Lane lane = board.getLaneAt(laneOf(source));
        if (lane == null) {
            return;
        }
        for (Zombie zombie : lane.getAllZombies()) {
            if (board.isZombieOnLawn(zombie)) {
                zombie.moveBy(distance, 0);
            }
        }
    }

    public void shiftLaneZombies(Plant source) {
        if (board == null || source == null) {
            return;
        }
        Lane lane = board.getLaneAt(laneOf(source));
        if (lane == null) {
            return;
        }
        for (Zombie zombie : new ArrayList<>(lane.getAllZombies())) {
            if (board.isZombieOnLawn(zombie)) {
                board.shiftZombieToAdjacentLane(zombie, random);
            }
        }
    }

    public void attractNearbyZombies(Plant source) {
        if (board == null || source == null) {
            return;
        }
        int targetLane = laneOf(source);
        for (Zombie zombie : new ArrayList<>(board.getAllZombies())) {
            if (!board.isZombieOnLawn(zombie)) {
                continue;
            }
            int zombieLane = Math.max(1, Math.min(board.getHeight(), (int) Math.round(zombie.getY())));
            if (Math.abs(zombieLane - targetLane) == 1) {
                board.moveZombieToLane(zombie, targetLane);
            }
        }
    }

    public void removeArmorFromRandom(int count) {
        if (board == null || count <= 0) {
            return;
        }
        List<Zombie> armored = new ArrayList<>();
        for (Zombie zombie : board.getAllZombies()) {
            if (board.isZombieOnLawn(zombie) && zombie.hasArmor()) {
                armored.add(zombie);
            }
        }
        armored.sort(Comparator.comparingInt(zombie -> -zombie.getArmor().getHp()));
        for (int index = 0; index < Math.min(count, armored.size()); index++) {
            armored.get(index).getArmor().reduceDamage(Integer.MAX_VALUE);
        }
    }

    public void clonePlant(Plant source, int count) {
        if (board == null || plantFactory == null || source == null || count <= 0) {
            return;
        }
        List<Position> empty = emptyPositions();
        Collections.shuffle(empty, random);
        int created = 0;
        for (Position position : empty) {
            if (created >= count) {
                break;
            }
            Plant clone = plantFactory.createPlant(
                    source.getType(),
                    position.getX(),
                    position.getY()
            );
            clone.setLevel(source.getLevel());
            String sourceName = normalize(source.getName());
            if (sourceName.equals("potato mine") || sourceName.equals("primal potato mine")) {
                clone.finishArming();
            }
            if (board.placePlant(clone, position)) {
                created++;
                if (plantPlacedHandler != null) {
                    plantPlacedHandler.accept(clone);
                }
            }
        }
    }

    public void cloneLilyPads(int count) {
        if (board == null || plantFactory == null || count <= 0) {
            return;
        }
        PlantType lilyPad = plantFactory.getPlantRegistry().getByName("Lily Pad");
        if (lilyPad == null) {
            return;
        }
        List<Position> positions = new ArrayList<>();
        for (Lane lane : board.getLanes()) {
            for (Tile tile : lane.getTiles()) {
                if (tile.getTileType().name().equals("WATER") && !tile.hasPlant()) {
                    positions.add(tile.getPosition());
                }
            }
        }
        Collections.shuffle(positions, random);
        for (int index = 0; index < Math.min(count, positions.size()); index++) {
            Position position = positions.get(index);
            Plant plant = plantFactory.createPlant(lilyPad, position.getX(), position.getY());
            if (board.placePlant(plant, position) && plantPlacedHandler != null) {
                plantPlacedHandler.accept(plant);
            }
        }
    }


    public void triggerSamePlantBarrage(String plantName, int durationTicks, int cooldownRate) {
        if (board == null || plantName == null) {
            return;
        }
        List<Plant> affected = new ArrayList<>();
        for (Plant candidate : board.getAllPlants()) {
            if (candidate == null || !candidate.isAlive()
                    || !normalize(candidate.getName()).equals(normalize(plantName))) {
                continue;
            }
            candidate.resetCooldown();
            candidate.setPlantFoodModifiers(1, Math.max(1, cooldownRate), false);
            String clip = normalize(candidate.getName()).equals("sea shroom") ? "pf" : "plantfood";
            candidate.triggerSpecialAnimation(clip);
            affected.add(candidate);
        }
        if (durationTicks > 0) {
            runDelayed(durationTicks, () -> {
                for (Plant candidate : affected) {
                    if (candidate != null && candidate.isAlive()) {
                        candidate.resetPlantFoodModifiers();
                    }
                }
            });
        }
    }

    public void killRandomWaterZombies(Plant source, int count, String damageType) {
        if (board == null || count <= 0) {
            return;
        }
        List<Zombie> water = new ArrayList<>();
        for (Zombie zombie : livingEnemies()) {
            Tile tile = board.getTileContainingZombie(zombie);
            if (tile != null && tile.getTileType().name().equals("WATER")) {
                water.add(zombie);
            }
        }
        Collections.shuffle(water, random);
        for (int index = 0; index < Math.min(count, water.size()); index++) {
            Zombie zombie = water.get(index);
            zombie.recordDamageSource(
                    source == null ? null : source.getName(),
                    source == null || source.getType() == null ? null : source.getType().getCategory(),
                    damageType
            );
            zombie.kill();
        }
    }

    public void resetPlantAges(String plantName) {
        if (board == null || plantName == null || plantAgeResetHandler == null) {
            return;
        }
        for (Plant plant : board.getAllPlants()) {
            if (normalize(plant.getName()).equals(normalize(plantName))) {
                plantAgeResetHandler.accept(plant);
            }
        }
    }

    public int countPlantLayers(Plant source) {
        if (board == null || source == null) {
            return 1;
        }
        Tile tile = board.getTileAt(positionOf(source));
        if (tile == null) {
            return 1;
        }
        int count = 0;
        for (Plant plant : tile.getPlants()) {
            if (normalize(plant.getName()).equals(normalize(source.getName()))) {
                count++;
            }
        }
        return Math.max(1, count);
    }

    public void damagePlant(Plant plant, int amount, String type) {
        if (plant != null && amount > 0) {
            plant.takeDamage(new Damage(amount, type));
        }
    }

    private List<Zombie> livingEnemies() {
        List<Zombie> result = new ArrayList<>();
        if (board == null) {
            return result;
        }
        for (Zombie zombie : board.getAllZombies()) {
            if (zombie != null && board.isZombieOnLawn(zombie) && !board.isHypnotized(zombie)) {
                result.add(zombie);
            }
        }
        return result;
    }

    private List<Position> emptyPositions() {
        List<Position> positions = new ArrayList<>();
        if (board == null) {
            return positions;
        }
        for (Lane lane : board.getLanes()) {
            for (Tile tile : lane.getTiles()) {
                if (!tile.hasPlant() && tile.isPlantable()) {
                    positions.add(tile.getPosition());
                }
            }
        }
        return positions;
    }

    private Position positionOf(Plant plant) {
        int x = board == null ? Math.max(1, (int) Math.round(plant.getX()))
                : Math.max(1, Math.min(board.getWidth(), (int) Math.round(plant.getX())));
        int y = board == null ? Math.max(1, (int) Math.round(plant.getY()))
                : Math.max(1, Math.min(board.getHeight(), (int) Math.round(plant.getY())));
        return new Position(x, y);
    }

    private int laneOf(Plant plant) {
        return positionOf(plant).getY();
    }

    private void record(BoardTickResult result) {
        if (resultRecorder != null && result != null) {
            resultRecorder.accept(result);
        }
    }

    private String normalize(String value) {
        return value == null ? "" : value.trim().toLowerCase()
                .replace('-', ' ').replace('_', ' ').replaceAll("\\s+", " ");
    }
}
